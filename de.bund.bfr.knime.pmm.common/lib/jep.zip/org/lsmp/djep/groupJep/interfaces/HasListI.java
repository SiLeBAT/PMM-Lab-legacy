/* @author rich
 * Created on 15-Mar-2004
 */
package org.lsmp.djep.groupJep.interfaces;

/**
 * Group implements a List function [a,b,c].
 * @author Rich Morris
 * Created on 15-Mar-2004
 */
public interface HasListI {
	public Number list(Number eles[]);
}
